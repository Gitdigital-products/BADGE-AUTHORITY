
import { Rule, ExecutionContext } from "@badge-authority/core";

export function evaluateRule(rule: Rule, context: ExecutionContext): boolean {
  const value = context[rule.field];

  switch (rule.operator) {
    case "greaterThan":
      return value > rule.value;
    case "equals":
      return value === rule.value;
    case "includes":
      return Array.isArray(value) && value.includes(rule.value);
    default:
      return false;
  }
}
