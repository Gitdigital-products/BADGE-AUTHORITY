
import { evaluateRule } from "./ruleEngine";

const rule = { field: "contributions", operator: "greaterThan", value: 5 };
const context = { contributions: 10 };

console.log("Rule valid:", evaluateRule(rule, context));
