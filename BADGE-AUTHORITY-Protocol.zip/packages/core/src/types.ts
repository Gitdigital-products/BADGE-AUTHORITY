
export type BadgeTier = "bronze" | "silver" | "gold" | "platinum";

export interface Badge {
  id: string;
  name: string;
  description: string;
  tier: BadgeTier;
  criteria: Rule[];
}

export interface Rule {
  field: string;
  operator: "greaterThan" | "equals" | "includes";
  value: any;
}

export interface ExecutionContext {
  [key: string]: any;
}
