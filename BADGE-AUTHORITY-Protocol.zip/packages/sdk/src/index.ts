
import { evaluateRule } from "@badge-authority/engine";
import { Rule, ExecutionContext } from "@badge-authority/core";

export function validate(rule: Rule, context: ExecutionContext) {
  return evaluateRule(rule, context);
}
