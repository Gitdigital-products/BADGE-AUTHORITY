import express from 'express';
const router = express.Router();

router.get('/badges', (req, res) => {
  res.json({ message: "List of badges" });
});

router.post('/badges/validate', (req, res) => {
  res.json({ message: "Validation endpoint" });
});

export default router;
