export function validateBadge(badge, rules) {
  for (const rule of rules) {
    if (!eval(rule.condition)) {
      return { valid: false, failedRule: rule.name };
    }
  }
  return { valid: true };
}
